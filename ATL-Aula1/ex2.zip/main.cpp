#include<cstdio>
#include<list>
#include<map>
#include<vector>
#include<cstring>

using namespace std;

int main( int argc, char* argv [] ) {

	vector < list<int> > m1 (1000);
	/* m1[i] representa os elementos incluidos no time i respeitando
	 * a ordem de ENQUEUE feito na entrada*/
	int numElementosNaFila[1000];
	map <int, int> team;
	/* Mapa usado para identificar em qual time o elemento pertence
	 * first key=elemento,second key= posicao do vector(time)
	 * Vai ser importante para fazer uma busca rapida na lista de times(variavel sequencia)*/
	list <int> sequencia;
	/* Na fila(sequencia) existira uma sequencia unica(SEM REPETICAO) dos times
	 * Que foram incluidos*/
	int numTimes, round, i, j, numELementos, elemento, posicaoVector;
	char palavra[8];

	for(i = 0; i < 1000; i++) 
		numElementosNaFila[i] = 0;
	round = 1;
	scanf("%d", &numTimes);
	while(numTimes != 0){
		//Associo cada time a uma posicao do vetor
		for(i = 0; i < numTimes; i++){	
			scanf("%d", &numELementos);
			for(j = 0; j < 	numELementos; j++){
				scanf("%d", &elemento);
				team.insert(pair<int,int>(elemento, i));
				//Insiro o elemento no time i
			}
		}

		printf("Scenario #%d\n", round++);
		do{
			scanf("%s", palavra);
			if(!strcmp(palavra,"ENQUEUE")){
				scanf("%d", &elemento);//Qual elemento que vai pra fila?
				posicaoVector = team.find(elemento)->second;//Pego o time a que esse elemento pertence
				m1[posicaoVector].push_back(elemento);//Coloca a ordem em que se encontra os elementos
				if(numElementosNaFila[posicaoVector] == 0)//Insere na fila o time se ele nao foi incluido
					sequencia.push_back(posicaoVector);
				numElementosNaFila[posicaoVector]++;//Anota que foi adicionado um elemento no time[posicaoVector]
				
			}else if(!strcmp(palavra,"DEQUEUE")){
				posicaoVector = sequencia.front();//Retira o primeiro time da lista
				//Se apenas 1 elemento no time pra ser retirado 
				if(numElementosNaFila[posicaoVector] == 1) {
					sequencia.pop_front();//Retira o time da fila
					numElementosNaFila[posicaoVector]--;
				}
				//Se houver mais de 1 elemento no time pra ser retirado
				else if(numElementosNaFila[posicaoVector] > 1)
				       	numElementosNaFila[posicaoVector]--;//Retira o numero de elementos na fila
				printf("%d\n", m1[posicaoVector].front());//Retira o elemento da fila do time
				m1[posicaoVector].pop_front();
			}
		}while(strcmp(palavra,"STOP") != 0);
		printf("\n");

		sequencia.clear();
		for(i = 0; i < numTimes; i++){
			numElementosNaFila[i] = 0;		
			m1[i].clear();//Apaga todos elementos pertencente ao time
		}
		scanf("%d", &numTimes);
	}
}

