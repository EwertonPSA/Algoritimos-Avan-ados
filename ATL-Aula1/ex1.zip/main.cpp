#include<map>
#include<cstdio>
/*
char* getInfo(){
	int tam = 128, count = 0;
	char* line;
	char letter;

	line = (char*)malloc(sizeof(char)*tam);
	letter = getc(stdin);
	while(letter != EOF && letter != '\n' && letter != 13){
		if(count != 0 && count % tam == 0)
			line = (char*)realloc(line, sizeof(char)*(count+tam));
		line[count] = letter;
		count++;
		letter = getc(stdin);
	}
	if(count == 0){
		free(line);
		return NULL;
	}
	line = (char*)realloc(line, sizeof(char)*(count+1));
	line[count] = '\0';
	return line;
}
*/
int main( int argc, char* argv [] ) {
	int vetor[2] = {0, 0};
	char letter;
	letter = getc(stdin);
	vetor[0] = (letter == ')');
	while(letter != EOF && letter != '\n' && letter != 13){
		if(letter == '(') vetor[0]++;
		else vetor[1]++;
		letter = getc(stdin);
	}
	if(vetor[0]-vetor[1] == 0) printf("YES\n");
	else printf("NO\n");
}
